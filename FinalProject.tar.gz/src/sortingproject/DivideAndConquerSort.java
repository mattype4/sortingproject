/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sortingproject;
import java.util.*;

/**
 *This class uses the quick sort and merger sort algorithms which are
 * divide and conquer algorithms.
 * 
 * <p>The merge sort is split into two methods:  mergeSort()- to
 * sort the merged pieces of the list and the other merge() - to
 * merge the broken pieces back into one.</p>
 * <p>Quick sort is also split into two methods:  quickSort() - to
 * sort through list and partition() - to partition the list to be
 * sorted.</p>
 * 
 * @author Matthew Hill
 * 
 * @version %I%, %G%
 * 
 * @since 1.0
 */
public class DivideAndConquerSort<T extends Comparable<? super T>> {
    

    /**
     * Recursively separates the list given until single values of the
     * list remain.
     * 
     * @param a This list that is to be merged.  It was given the variable
     *          a to easily distinguish between it and the separated 
     *          children b and c that it creates.
     */
    public void mergeSort(DoublyLinkedList<T> a){
        int n = a.getLength();
        DoublyLinkedList<T> b, c;
        b = new DoublyLinkedList<T>();
        c = new DoublyLinkedList<T>();
        
        if (n > 1){
            for(int i = 1; i <= (n/2); i++){
                b.addNode(a.getNode(i).getData());
            }
            for(int i = ((n/2) +1); i <= n; i++){
                c.addNode(a.getNode(i).getData());
            }
            mergeSort(b);
            mergeSort(c);
            merge(b, c, a);
        }
    }
    
    /**
     * Brings back and helps sort the divided list from the mergeSort()
     * method.  This method changes the list of a to be sorted.
     * 
     * @param b The first list chosen and compared to help sort into a
     * @param c The second list that is to be compared with b.
     * @param a The list that is to be created is the sorted result of
     *          b and c.
     */
    public void merge(DoublyLinkedList<T> b, DoublyLinkedList<T> c,
                            DoublyLinkedList<T> a){
        int i = 1, j = 1, k = 1;
        while (i <= b.getLength() && j <= c.getLength()){
            if (b.getNode(i).getData().compareTo(c.getNode(j).getData()) <= 0){
                a.getNode(k).setData(b.getNode(i).getData());
                i++;
            } else{
                a.getNode(k).setData(c.getNode(j).getData());
                j++;
            }
            k++;
        }
        
        if(i == (b.getLength() + 1)){
            for (int m = j; m <= c.getLength(); m++){
                a.getNode(k).setData(c.getNode(m).getData());
                k++;
            }
        }else
            for (int m = i; m <= b.getLength(); m++){
                a.getNode(k).setData(b.getNode(m).getData());
                k++;
            }
    }
    
    /**
     * quickSort is just listed to let the user easily pass a list
     * to it so that the rest of the quick sort methods can sort it.
     * 
     * @param list List to be sorted. 
     */
    public void quickSort(DoublyLinkedList<T> list){
        int left = 1;
        int right = list.getLength();
        quick(list, left, right);
    }
    
    /**
     * The recursive step happens in this method.  This method is to simplify
     * the code and separate the recursive steps.
     * 
     * @param list The list that is to be sorted
     * @param left left bound of the list
     * @param right right bound of the list
     */
    public void quick(DoublyLinkedList<T> list, int left, int right){
        int l = left, r = right, s;
        
        if (l < r){
            s = partition(list, l, r);
            quick(list, l, (s - 1));
            quick(list, (s + 1), r);
        }
    }
    
    /**
     * This is the core of the quick sort algorithm and does most of the
     * sorting.  The book was a good reference, and the partition value
     * used was based off of the first value of the array placed into
     * the method.  The other values are scanned and moved around
     * based off of this partition value.
     * 
     * @param list The original list to be sorted
     * @param left This gives the left bound of the list
     * @param right Gives the right bound of the list
     * 
     * @return The index of where the list should be split for further
     *         sorting.
     */
    public int partition(DoublyLinkedList<T> list, int left, int right){
        T part = list.getNode(left).getData();
        int i = left;
        int j = right+1;
        
        do{
            do{
                i++;
            } while (i < right && list.getNode(i).getData().compareTo(part) < 0);
            
            do{
                j--;
            } while (list.getNode(j).getData().compareTo(part) > 0);
            
            swap (list.getNode(i), list.getNode(j));
            
        } while (i < j);

        swap (list.getNode(i), list.getNode(j));
        swap (list.getNode(left), list.getNode(j));
        
        return j;
    }
    
    /**
     * The swap method is used for the quick sort algorithm.  While quick sort
     * is comparing values to the partition value, the swap method will swap
     * the values appropriately.
     * 
     * @param node1 The first node to be swapped
     * @param node2 The second node to be swapped
     */
        private void swap(Node<T> node1, Node<T> node2)
    {
        Node<T> temp = new Node<T>(node1.getData());
        node1.setData(node2.getData());
        node2.setData(temp.getData());
    }
    
    
}
