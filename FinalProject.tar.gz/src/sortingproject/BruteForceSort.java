
package sortingproject;
import java.util.*;

/**
 * <p>The BruteForceSort classes uses two very popular sort algorithms
 * used for sorting, the Bubble Sort and the Selection Sort.  A swap method
 * is also implemented here, because both sorts make use out of it.</p>
 * 
 * @author Matthew Hill
 * 
 * @version %I%, %G%
 * 
 * @since 1.0
 */
public class BruteForceSort<T extends Comparable<? super T>> {
        
    /**
     * Uses the Bubble Sort algorithm.  The largest value starting at
     * the beginning of the list is "pushed throughout the list into
     * its rightful place.
     * 
     */
    public void bubbleSort(DoublyLinkedList<T> list ){
        for (int i = 1; i <= (list.getLength()- 1); i++){
            for (int j = 1; j <= (list.getLength() - i); j++ ){
                if (list.getNode(j).getData().compareTo(list.getNode(j + 1).getData()) > 0){
                    swap(list.getNode(j), list.getNode(j + 1));
                }
            }
        }
        
    }
    
    public void reverseSort(DoublyLinkedList<T> list ){
        for (int i = 1; i <= (list.getLength()- 1); i++){
            for (int j = 1; j <= (list.getLength() - i); j++ ){
                if (list.getNode(j).getData().compareTo(list.getNode(j + 1).getData()) < 0){
                    swap(list.getNode(j), list.getNode(j + 1));
                }
            }
        }
        
    }
    
    /**
     * Uses the Selection Sort algorithm.  A value is held (starting at the
     * beginning).  It is compared to the rest of the list and swapped if it
     * is smaller.  This continues throughout the list to produce a sorted list.
     */
    public void selectionSort(DoublyLinkedList<T> list){
       int min;
       
       for(int i=1; i<=list.getLength()-1; i++){
            min = i;
           
            for(int j=i+1; j<=list.getLength(); j++){
                
                if(list.getNode(j).getData().compareTo(list.getNode(min).getData()) < 0){
                    min = j;
                }
            }
        swap(list.getNode(i), list.getNode(min)); 
        }

    }
    
    /**
     * The swap method selects two nodes and switches whatever values
     * contained in them with each other
     * 
     * @param node1 the first node to be swapped
     * @param node2 the second node to be swapped by the first
     */
    private void swap(Node<T> node1, Node<T> node2)
    {
        Node<T> temp = new Node<T>(node1.getData());
        node1.setData(node2.getData());
        node2.setData(temp.getData());
    }
    
    
}
