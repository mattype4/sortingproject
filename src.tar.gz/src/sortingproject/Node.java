package sortingproject;
/**
 * <p>Node is the basic build for this project.  All entries
 * created in a table will be consisted of the Node class.
 * This class is of generic types.</p>
 * 
 * @author Matthew Hill
 * 
 * @version %I%, %G%
 * 
 * @since 1.0
 */
public class Node<T> {
    /**
     * The link for the next node
     */
    private Node<T> next;
    
    /**
     * the link for the previous node
     */
    private Node<T> prev;
    
    /**
     * the data that this.node holds
     */
    private T data;
    
    /**
     * sole constructor
     * 
     * @param data a data of type T to be stored
     *              in the node.
     */
    public Node(T data){
        this.next = null;
        this.prev = null;
        this.data = data;
    }

    /**
     * Alternate constructor
     * 
     * @param next assigns what the next node should be
     * @param prev assigns what the previous node should be
     * @param data assigns a type T data to this.node
     */
    public Node(Node<T> next, Node<T> prev, T data){
        this.next = next;
        this.prev = prev;
        this.data = data;
    }
    
    /**
     * Setter for next in the node
     * 
     * @param next assigns next node
     */
    public void setNext(Node<T> next){
        this.next = next;
    }
    
    /**
     * Setter for previous node
     * 
     * @param assigns previous node
     */
    public void setPrev(Node<T> prev){
        this.prev = prev;
    }
    
    /**
     * Setter for the data of the node
     * 
     * @param a type T data to be placed in the node
     */
    public void setData(T data){
        this.data = data;
    }
    
    /**
     * Getter for the next node
     * 
     * @return The next node
     */
    public Node<T> getNext(){
        return next;
    }
    
    /**
     * Getter for the previous node
     * 
     * @return The previous node
     */
    public Node<T> getPrev(){
        return prev;
    }
    
    /**
     * Getter for the data of the node
     * 
     * @return The data within the node
     */
    public T getData(){
        return data;
    }
    
    
}
