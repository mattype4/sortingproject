package sortingproject;

/**
 * <p>The DoublyLinkedList creates an array of nodes
 * from the Node.java file and uses the Node class
 * as entries into its array.  This array is used
 * to create a list of generic types and allows 
 * the manipulation of data within the list.</p>
 * 
 * @author matthewhill
 * 
 * @version %I%, %H%
 * 
 * @since 1.0
 */
public class DoublyLinkedList<T> {
    /**
     * The head of the list (beginning),
     * it is supposed to stay null
     */
    Node<T> head = new Node<T>(null);
    
    /**
     * The tail of the list (end),
     * it is supposed to stay null
     */
    Node<T> tail = new Node<T>(null);
    
    /**
     * this.length is the  length of the list,
     * 1 starting at the first node that contains
     * data (not the head).  The final listing of
     * length should be the last value.
     */
    private int length = 0;
    
    /**
     * Sole constructor of the class
     */
    public DoublyLinkedList(){
        head.setNext(tail);
        head.setPrev(null);
        tail.setNext(null);
        tail.setPrev(head);
        
    }
    
    /**
     * Returns the node of the chosen index by the user.
     * 
     * @param index The index in which the user would like
     *               to retrieve the node.
     * 
     * @return The node that was selected by the index
     */
    public Node<T> getNode(int index) throws IndexOutOfBoundsException{
        if (index<0 || index>length){
            throw new IndexOutOfBoundsException();
        }
        else{
            Node<T> cursor = head;
            for(int i=0; i<index; i++){
                cursor = cursor.getNext();
            }
        
            return cursor;
        }
    }
    
    /**
     * This adds a node at the end of the list (before the
     * tail) and enters the value from the parameter
     * 
     * @param data The new node will be using this value
     * 
     */
    public void addNode(T data){
        Node<T> node = new Node<T>(data);
        Node<T> cursor = tail.getPrev();
        cursor.getNext().setPrev(node);
        node.setNext(cursor.getNext());
        cursor.setNext(node);
        node.setPrev(cursor);
        length++;
    }
    
    /**
     * Adds a node to the selected index with the value data
     * 
     * @param index the place in which the user would like to add the node
     * @param data will make the node contain this value
     * 
     * @throws IndexOutOfBoundsException the user should not input
     *                                   an index value that is too large
     *                                   or below 0.
     */
    public void addNode(int index, T data) throws IndexOutOfBoundsException{
        
        Node<T> node = new Node<T>(data);
        Node<T> cursor = getNode(index);
        node.setNext(cursor.getNext());
        node.setPrev(cursor);
        cursor.getNext().setPrev(node);
        cursor.setNext(node);
        length++;
    }
    
    /**
     * Adds a node right after the head of the list (length =1).
     * 
     * @param data Gives the added node the value of data
     */
    public void addHead(T data){
        Node<T> node = new Node<T>(data);
        Node<T> cursor = head;
        cursor.getNext().setPrev(node);
        cursor.setNext(node);
        node.setNext(cursor.getNext());
        node.setPrev(cursor);

        length++;
    }
    
    /**
     * Removes a node at the selected index
     * 
     * @param index Chooses where the node should be removed from
     * 
     * @return The node that is removed from the list
     * 
     * @throws IndexOutOfBoundsException If the user inputs an out of bounds
     *                                   index
     */
    public T rmNode(int index) throws IndexOutOfBoundsException{
        if(length==0){
            throw new IndexOutOfBoundsException();
        }
        else{
            Node<T> node = getNode(index);
            node.getNext().setPrev(node.getPrev());
            node.getPrev().setNext(node.getNext());
            
            
            length--;
            return node.getData();
        }    
    }
    
    /**
     * A getter method for returning the length of the list
     * 
     * @return The length of the list
     */
    public int getLength(){
        return length;
    }
    
    /**
     * Prints out whatever may be in the nodes of the list from the
     * first node to the last (excluding the head and tail nodes)
     */
    public void print(){
        for(int i=1; i<=getLength(); i++){
            System.out.print(getNode(i).getData() + " ");
        }
        System.out.println();
    }
    

    
    
    
}
