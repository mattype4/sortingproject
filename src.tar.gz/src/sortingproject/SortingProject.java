package sortingproject;
import java.io.*;
import java.util.*;
/**
 *Driver program (just testing)
 * 
 * @author Matthew Hill
 * 
 * @version %I%, %G%
 * 
 * @since 1.0
 */
public class SortingProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        
        DoublyLinkedList<Integer> link = new DoublyLinkedList<Integer>();
        Random randomGenerator = new Random();
        File file = new File("./output.txt");
        long startTime, stopTime;
        int num;
        
        /*
         You may use the buffer writer to output random values
         into a text file (named "output.txt") by uncommenting
         the below function calls.  Just change the i value
         for whatever size you see fit.
          
        FileWriter fstream = new FileWriter(file);
        BufferedWriter out = new BufferedWriter(fstream);
        for(int i = 0; i < 100; i++){
            num = randomGenerator.nextInt();
            
            out.write(Integer.toString(num));
            out.newLine();

        }
        out.close();
        */


            
        /*
         * Below the Scanner read will read from the "output.txt" file
         * that came with the documentation of the project.  The
         * file should be delimited by whitespaces or returns.
         */
        Scanner read = new Scanner(file);
        
        while (read.hasNext()){
            link.addNode(read.nextInt());
        }
        
        
        link.print();
        
        //Instantiation of divide and conquer classes
        //refers to merge sort and quick sort
        DivideAndConquerSort check1 = new DivideAndConquerSort();
        
        //Instantiation of brute force classes
        //refers to bubble sort and selection sort
        BruteForceSort check = new BruteForceSort(); 
        
        //The following just prints out values within the list
        //should be from "output.txt"
        System.out.println("Link");
        link.print();
        System.out.println();
        
        /**
         * Times and sorts with merge sort
         */
        startTime = System.nanoTime();
        check1.mergeSort(link);
        stopTime = System.nanoTime();
        System.out.println("Total time for sort:  " +
                (stopTime - startTime));
        
        
        
        /**
         * Times and sorts with quick sort
         *
        startTime = System.nanoTime();
        check1.quickSort(link);
        stopTime = System.nanoTime();
        System.out.println("Total time for sort:  " +
                (stopTime - startTime));
         */
        
        
        
        /**
         * Times and sorts with selection sort
         *
        startTime = System.nanoTime();
        check.selectionSort(link);
        stopTime = System.nanoTime();
        System.out.println("Total time for sort:  " +
                (stopTime - startTime));
         */
        
        
        
        /**
         * Times and sorts with bubble sort
         
        startTime = System.nanoTime();
        check.bubbleeSort(link);
        stopTime = System.nanoTime();
        System.out.println("Total time for sort:  " +
                (stopTime - startTime));
        */
       
        System.out.println("Link 1 sorted:  ");
        link.print();

    }
}
