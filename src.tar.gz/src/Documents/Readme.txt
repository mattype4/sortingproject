Author:  Matthew Hill
Date:  December 2, 2011
Professor:  Andrew Temlyakov
File:  Readme.txt
Purpose:  Final Project Documentation

***********************************************
The src.tar.gz package contains the src code
of the main project.  It contains all the .java files
and documentation of the experiments performed for 
the different sorts.

The following files can be found in the src folder:

Node.java
DoublyLinkedList.java
BruteForceSort.java
DivideAndConquerSort.java
SortingProject.java (the main class)

***********************************************

*It is preferrable to use some sort of IDE (Eclipse, Netbeans, ...).*

I used NetBeans to run the different java classes, but
they can just as easily be ran in the command console.
To do so perform the following:

Extract files into desired directory
cd to that directory and cd into the src folder
make sure you are in the directory of the .java files
compile by typing in the following:

	javac Node.java DoublyLinkedList.java BruteForceSort.java
		DivideAndConquer.java SortingProject.java

This should create all the .class files for the java files
Go back up into previous directory i.e. cd ..
execute the main by typing:

	java soringproject.SortingProject 

and the program will execute

The above may seem tedious but is neccessary if it is desirable to run in the terminal.
It is much easier to run it through some sort of IDE such as Eclipse or Netbeans.

A Makefile would have been used, but Makefiles and java programs do not seem to get along
that well.  I left the option of execution to the user to provide more freedom.

***********************************************

The output.txt file located with the package can be altered to provide a list
to be sorted by the main program.  Just go into the file and input the numbers of
your choice delimited by whitespace and/or returns.

The file comes with a randomly allocated list.  If you wish to produce another,
just uncomment the section within the main class (SortingProject.java) that
uses the WriteBuffer and change the value of i to produce an i length list.

***********************************************

All of the sorts are already listed in the program, but the mergeSort() is the
only one that will execute initially.  If another sort is to be used, just uncomment
the chosen sort and comment the mergeSort() or replace the call with desired sort.

The sorts could have been separated in different driver programs, but again the choice
was left by the user for use of freedom.

